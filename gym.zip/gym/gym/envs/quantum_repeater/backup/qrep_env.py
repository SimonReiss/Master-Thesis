import gym
from gym import spaces
from gym.utils import seeding
import sys
from time import sleep

import numpy as np

class QrepEnv(gym.Env):
	"""q-rep environment
	Internally the enviroment uses matrices for the state and the actions.
	Thus at the interface transformations of them is necessary.
	"""
	def __init__(self, number_of_segments=4, p=0.1, epsilon=0.08, discard_empty_penalty = 0.0):
		assert discard_empty_penalty==0.0 or discard_empty_penalty>0.5, "\n\ndiscard_empty_panelty to small, breaks algorithm!!"
		assert (number_of_segments % 2 == 0), "\n\nInvalid number of segments! Balanced swapping means 2^n segments!\n\n"
		self.p = p # probability of distributing entanglement within a timestep
		self.epsilon = epsilon # probability of a phase flip on a memory within a timestep
		self.number_of_segments = number_of_segments # number of segments
		self.discard_empty_penalty = np.abs(discard_empty_penalty)
		self.state = np.zeros((self.number_of_segments,self.number_of_segments))
		"""
		The occupied_ vectors store the occupation. True corresponds to unoccupied.
		The index of occupied left is logically shifted by one.
		"""
		self.occupied_left = np.ones(self.number_of_segments)
		self.occupied_right = np.ones(self.number_of_segments)

		number_of_links = int((number_of_segments*(number_of_segments+1))/2)
		# self.action_space = spaces.Box(low=0.0, high=1.0, shape=(number_of_links,), dtype=np.float32)
		self.action_space = spaces.MultiDiscrete(2*np.ones(number_of_segments-1 + number_of_links))
		#state_type = np.int32
		#self.observation_space = spaces.Box(low=0.0, high=np.iinfo(state_type).max, shape=(number_of_links,), dtype=state_type)        
		self.observation_space = spaces.MultiDiscrete(np.iinfo(np.int32).max*np.ones(number_of_links))
		self.seed()

	def seed(self, seed=None):
		self.np_random, seed = seeding.np_random(seed)
		return [seed]

	def step(self, action):
		assert self.action_space.contains(action), "%r (%s) invalid"%(action, type(action))		

		# agent action
		action_matrix = np.zeros((self.number_of_segments, self.number_of_segments))
		action_matrix[np.triu_indices(self.number_of_segments)] = action[number_of_segments-1:]
		penalty = np.sum(np.logical_and(np.logical_not(action_matrix),np.logical_not(self.state))) # number of discarding non existing state
		occ_matrix = np.multiply(np.logical_not(action_matrix),np.logical_xor(action_matrix,self.state))
		self.occupied_right = np.logical_or(occ_matrix.any(1),self.occupied_right)
		self.occupied_left = np.logical_or(occ_matrix.any(0),self.occupied_left)        
		self.state = np.multiply(action_matrix,self.state)

		# natural evolution of the enviroment
		self.generate_entanglement()
		self.decohere_memories()

		self.swap_balanced()

		# collecting reward
		quality_parameter = self.get_quality()
		if (quality_parameter != 0):
			reward = self.fidelity(quality_parameter)
			self.discard(0, self.number_of_segments)
		else:
			reward = 0
		reward -= penalty*self.discard_empty_penalty
		done = False
		return self.state[np.triu_indices(len(self.state))].flatten(), reward, done, {}

	def reset(self):
		self.state = np.zeros((self.number_of_segments,self.number_of_segments))
		self.occupied_left = np.ones(self.number_of_segments)
		self.occupied_right = np.ones(self.number_of_segments)
		return self.state[np.triu_indices(len(self.state))].flatten()

###############################################################
# Functions to operate the enviroment
###############################################################

	def generate_entanglement(self):
		v = np.random.rand(self.number_of_segments)
		v[v<=self.p] = -1
		v[v>self.p] = 0
		v = np.multiply(v,self.occupied_right)
		v = np.multiply(v,self.occupied_left)
		self.state = np.add(self.state,np.diag(v))
		self.occupied_right = np.logical_xor(v,self.occupied_right)
		self.occupied_left = np.logical_xor(v,self.occupied_left)

	def decohere_memories(self):
		self.state[ self.state > 0 ] += 1
		self.state[ self.state < 0 ] = 1

	def swap(self,s1,s2,s3):
		"""
		Assumes s1 < s2 < s3 ! Otherwise will not perform any action. Returns True if successfully swapped. False otherwise.
		"""
		assert s1 < s2 and s2 < s3 and self.state[s1][s2-1] >= 0 and self.state[s2][s3-1] >= 0, "\n\nInvalid swapping operation\n\n"
		if s1 < s2 and s2 < s3 and self.state[s1][s2-1] > 0 and self.state[s2][s3-1] > 0:
			self.state[s1][s3-1] = self.state[s1][s2-1] + self.state[s2][s3-1]
			self.discard(s1,s2)
			self.discard(s2,s3)
			self.occupied_right[s1] = False
			self.occupied_left[s3-1] = False
			return True
		return False

	"""
	def swap_at_station(self,s):
		indices = np.nonzero(np.append(self.state[s],np.transpose(self.state)[s-1]))
		assert (len(indices) == 0 or len(indices) == 2) and indices[0][1]+1 == indices[1][0]
		return self.swap(indices[0][0],indices[0][1]+1,indices[1][1]+1)
	"""

	def swap_balanced(self):		
		number_of_sub_segments = self.number_of_segments / 2
		size_of_sub_segments = self.number_of_segments / number_of_sub_segments
		while number_of_sub_segments > 0:
			for seg in range(int(number_of_sub_segments)):
				self.swap( int(seg*size_of_sub_segments), int((seg+0.5)*size_of_sub_segments), int((seg+1)*size_of_sub_segments))
			number_of_sub_segments /= 2
			size_of_sub_segments *= 2

	def discard(self, s1, s2):
		if s1 < s2:
			self.state[s1][s2-1] = 0
			self.occupied_right[s1] = True
			self.occupied_left[s2-1] = True
			return
		if s2 < s1:
			self.state[s2][s1-1] = 0
			self.occupied_right[s2] = True
			self.occupied_left[s1-1] = True
			return

	def get_quality(self):
		return self.state[0][self.number_of_segments-1]

	def render(self,mode='',render_delay=2):
		outfile = sys.stdout
		if (self.number_of_segments == 2):
			state_string = "\n" + "X----------" + str(int(self.state[0][self.number_of_segments-1])) + "----------X"
			state_string += "\n" + "X-----" + str(int(self.state[0][self.number_of_segments-2])) + "-----X"
			state_string += "-----" + str(int(self.state[1][self.number_of_segments-1])) + "-----X" + "\n\n"
			outfile.write(state_string)
			sleep(render_delay)
			return

		raise NotImplementedError

###############################################################
# Miscellancious functions
###############################################################

	def fidelity(self, quality_parameter):
		return 0.5 * ( 1 + np.power( ( 1 - 2 * self.epsilon ) , quality_parameter ))
