from .qrep_env import QrepEnv
from .qrep_env_generalParameter import QrepEnv as QrepEnv2

class QrepEnv4_01_008(QrepEnv2):
	def __init__(self):
		super().__init__(4, 0.1, 0.08, 0.0)

class QrepEnv4_20_100(QrepEnv):
	def __init__(self):
		super().__init__(4, 20, 0.0001)

class QrepEnv4_35_100(QrepEnv):
	def __init__(self):
		super().__init__(4, 35, 0.0001)

class QrepEnv4_50_100(QrepEnv):
	def __init__(self):
		super().__init__(4, 50, 0.0001)

class QrepEnv4_70_100(QrepEnv):
	def __init__(self):
		super().__init__(4, 70, 0.0001)

class QrepEnv4_20_1000(QrepEnv):
	def __init__(self):
		super().__init__(4, 20, 0.001)

class QrepEnv4_35_1000(QrepEnv):
	def __init__(self):
		super().__init__(4, 35, 0.001)

class QrepEnv4_50_1000(QrepEnv):
	def __init__(self):
		super().__init__(4, 50, 0.001)

class QrepEnv4_70_1000(QrepEnv):
	def __init__(self):
		super().__init__(4, 70, 0.001)

class QrepEnv4_20_10000(QrepEnv):
	def __init__(self):
		super().__init__(4, 20, 0.01)

class QrepEnv4_35_10000(QrepEnv):
	def __init__(self):
		super().__init__(4, 35, 0.01)

class QrepEnv4_50_10000(QrepEnv):
	def __init__(self):
		super().__init__(4, 50, 0.01)

class QrepEnv4_70_10000(QrepEnv):
	def __init__(self):
		super().__init__(4, 70, 0.01)

class QrepEnv4_20_100000(QrepEnv):
	def __init__(self):
		super().__init__(4, 20, 0.1)

class QrepEnv4_35_100000(QrepEnv):
	def __init__(self):
		super().__init__(4, 35, 0.1)

class QrepEnv4_50_100000(QrepEnv):
	def __init__(self):
		super().__init__(4, 50, 0.1)

class QrepEnv4_70_100000(QrepEnv):
	def __init__(self):
		super().__init__(4, 70, 0.1)
